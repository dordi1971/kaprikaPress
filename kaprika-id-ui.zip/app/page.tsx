'use client'
import { FormEvent, useState } from 'react'
import { useAccount } from 'wagmi'
import { WalletButton } from '@/components/WalletButton'
import { PhotoUploader } from '@/components/PhotoUploader';


const ADMIN_WALLETS =
  (process.env.NEXT_PUBLIC_ADMIN_WALLETS ?? '')
    .split(',')
    .map((w) => w.trim().toLowerCase())
    .filter(Boolean)

export default function HomePage() {
  const { address, isConnected } = useAccount()

  const isAdmin =
    isConnected &&
    !!address &&
    ADMIN_WALLETS.includes(address.toLowerCase())

  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [alias, setAlias] = useState('')
  const [role, setRole] = useState('Journalist')
  const [country, setCountry] = useState('')
  const [city, setCity] = useState('')
  const [result, setResult] = useState<{
    txHash?: string
    imageUrl?: string
    pdfUrl?: string
  } | null>(null)

  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [deliveryAddress, setDeliveryAddress] = useState('')

  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [statusMsg, setStatusMsg] = useState<string | null>(null)

  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()

    if (!isConnected || !address) {
      setStatusMsg('Please connect your wallet first.')
      return
    }
    if (!photoFile) {
      setStatusMsg('Please upload a photo.')
      return
    }

    setSubmitting(true)
    setStatusMsg(null)
    setResult(null)

    try {
      const formData = new FormData()
      formData.append('wallet', address)
      formData.append('firstName', firstName)
      formData.append('lastName', lastName)
      formData.append('alias', alias)
      formData.append('role', role)
      formData.append('country', country)
      formData.append('city', city)

      formData.append('email', email)
      formData.append('phone', phone)
      formData.append('deliveryAddress', deliveryAddress)

      formData.append('photo', photoFile)

      const res = await fetch('/api/mint-card', {
        method: 'POST',
        body: formData,
      })

      const data = await res.json()

      if (!res.ok) {
        console.error('Mint error:', data)
        setStatusMsg(`Error: ${data.error || 'Failed to mint'}`)
        return
      }

      setStatusMsg(
        `Minted successfully! Tx hash: ${data.txHash?.slice(
          0,
          10,
        )}… (check in block explorer)`,
      )
    } catch (err) {
      console.error(err)
      setStatusMsg('Unexpected error submitting form.')
    } finally {
      setSubmitting(false)
    }
  }


  return (
    <main className="min-h-screen flex flex-col items-center bg-slate-950 text-slate-50">
      <div className="w-full max-w-3xl px-4 py-8">
        <header className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-semibold">
            Kingdom of Kaprika – Press ID Mint
          </h1>
          <div className="flex items-center gap-3">
            {isAdmin && (
              <a
                href="/admin"
                className="px-3 py-1 text-xs rounded-md border border-emerald-400/60 text-emerald-200 hover:bg-emerald-500/10"
              >
                Admin panel
              </a>
            )}
            <WalletButton />
          </div>
        </header>


        {!isConnected && (
          <p className="mb-6 text-sm text-slate-300">
            Connect your MetaMask wallet to mint your Kaprika Press ID NFT.
          </p>
        )}

        <form
          onSubmit={handleSubmit}
          className="space-y-6 border border-slate-700 rounded-xl p-6 bg-slate-900/60"
        >
          <fieldset className="space-y-4" disabled={!isConnected || submitting}>
            <legend className="font-semibold mb-2">
              Card information (on-chain + on card)
            </legend>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-1">First name</label>
                <input
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={firstName}
                  onChange={e => setFirstName(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-1">Last name</label>
                <input
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={lastName}
                  onChange={e => setLastName(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-1">
                  Alias / Press name (optional)
                </label>
                <input
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={alias}
                  onChange={e => setAlias(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm mb-1">Role</label>
                <select
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={role}
                  onChange={e => setRole(e.target.value)}
                >
                  <option>Journalist</option>
                  <option>Photographer</option>
                  <option>Editor</option>
                  <option>Producer</option>
                  <option>Press</option>
                </select>
              </div>
              <div>
                <label className="block text-sm mb-1">Country (optional)</label>
                <input
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={country}
                  onChange={e => setCountry(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm mb-1">City (optional)</label>
                <input
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={city}
                  onChange={e => setCity(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1">
                Portrait photo (for card)
              </label>
              <PhotoUploader
                label="ID photo"
                initialPreviewUrl={photoPreview ?? undefined}
                onChange={(file, previewUrl) => {
                  setPhotoFile(file);
                  setPhotoPreview(previewUrl);
                  // if you use react-hook-form, this is where you'd do setValue('photo', file)
                }}
              />
            </div>
          </fieldset>

          <fieldset
            className="space-y-4 border-t border-slate-700 pt-4"
            disabled={!isConnected || submitting}
          >
            <legend className="font-semibold mb-2">
              Delivery details (off-chain only)
            </legend>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-1">Email</label>
                <input
                  type="email"
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-1">Phone</label>
                <input
                  className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm mb-1">
                Delivery address (for physical card)
              </label>
              <textarea
                className="w-full px-3 py-2 rounded-md bg-slate-800 border border-slate-700"
                rows={3}
                value={deliveryAddress}
                onChange={e => setDeliveryAddress(e.target.value)}
                required
              />
            </div>

            <p className="text-xs text-slate-400">
              These details are stored off-chain and used only to produce and
              deliver your physical Kaprika Press ID card.
            </p>
          </fieldset>

          <button
            type="submit"
            disabled={!isConnected || submitting}
            className="px-6 py-2 rounded-md bg-emerald-500 text-slate-950 font-semibold disabled:opacity-50"
          >
            {submitting ? 'Minting…' : 'Mint Kaprika Press ID'}
          </button>

          {statusMsg && (
            <p className="text-sm mt-2 text-slate-200">{statusMsg}</p>
          )}

          {result && (
            <div className="mt-4 text-sm space-y-1 text-slate-200">
              {result.txHash && (
                <div>
                  Tx hash:{' '}
                  <a
                    href={`https://amoy.polygonscan.com/tx/${result.txHash}`}
                    target="_blank"
                    rel="noreferrer"
                    className="underline"
                  >
                    {result.txHash.slice(0, 10)}…
                  </a>
                </div>
              )}
              {result.imageUrl && (
                <div>
                  Card image:{' '}
                  <a
                    href={result.imageUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="underline"
                  >
                    open
                  </a>
                </div>
              )}
              {result.pdfUrl && (
                <div>
                  Card PDF:{' '}
                  <a
                    href={result.pdfUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="underline"
                  >
                    download
                  </a>
                </div>
              )}
            </div>
          )}


          {statusMsg && (
            <p className="text-sm mt-2 text-slate-200">{statusMsg}</p>
          )}
        </form>
      </div>
    </main>
  )
}
